MODPATH=${0%/*}

# log
LOGFILE=$MODPATH/debug.log
exec 2>$LOGFILE
set -x

# ============================================
# FIX: PQ LOG SPAM (MTK-only, gated)
# ============================================
case "`getprop ro.board.platform``getprop ro.hardware``getprop ro.mediatek.platform`" in
  *mt6*|*MT6*|*mtk*|*MTK*) IS_MTK=true ;;
  *) IS_MTK=false ;;
esac
if [ "$IS_MTK" = true ]; then
  for PROC in mm-pq-daemon pq mm-pq mm_qdss_pq; do
    killall -9 $PROC 2>/dev/null
    pkill -9 -f $PROC 2>/dev/null
  done

  stop mm-pq-daemon 2>/dev/null
  stop pq 2>/dev/null

  resetprop -n persist.vendor.pq.log.level 0
  resetprop -n vendor.pq.disable.log 1
  setprop log.tag.PQ E 2>/dev/null
  setprop log.tag.MMLPQ E 2>/dev/null

  logcat -b all -c 2>/dev/null
  dmesg -c 2>/dev/null
fi

# ============================================
# ORIGINAL CODE - NO KILLING (REMOVED killall)
# ============================================

# var
API=`getprop ro.build.version.sdk`
if [ ! -d $MODPATH/vendor ] || [ -L $MODPATH/vendor ]; then
  MODSYSTEM=/system
fi

# property
resetprop -n ro.audio.ignore_effects false
resetprop -n ro.feature.dolby_enable true
resetprop -n ro.dolby.music_stream false
resetprop -n vendor.audio.dolby.ds2.enabled true
resetprop -n vendor.audio.dolby.ds2.hardbypass false
resetprop -n persist.vendor.dolby.ds2.enabled true

# ============================================
# REMOVED: ALL killall AND stop COMMANDS
# ============================================

# mount
DIR=/odm/bin/hw
FILES="$DIR/vendor.dolby.hardware.dms@1.0-service
       $DIR/vendor.dolby.hardware.dms@2.0-service"
if [ "`realpath $DIR 2>/dev/null`" = "$DIR" ]; then
  for FILE in $FILES; do
    [ -f "$FILE" ] && mount -o bind "$MODPATH$MODSYSTEM/vendor$FILE" "$FILE" 2>/dev/null
  done
fi

# permission
chmod 0755 "$MODPATH$MODSYSTEM/vendor/bin/hw/"* 2>/dev/null
chown 0.2000 "$MODPATH$MODSYSTEM/vendor/bin/hw/"* 2>/dev/null

# run Dolby service (only if not already running)
SERVICE=/vendor/bin/hw/vendor.dolby.hardware.dms@1.0-service
if [ -f "$SERVICE" ] && ! pidof "$SERVICE" >/dev/null 2>&1; then
  $SERVICE &
  sleep 2
fi

# Also (re)start dms-hal-2-0/dms-hal-1-0 if the ROM declares them as
# init services (these are service NAMES, not file paths -- must go
# through init's start command, not be exec'd directly)
for HAL in dms-hal-2-0 dms-hal-1-0; do
  start $HAL 2>/dev/null
done

# ============================================
# REMOVED: ALL killall FOR VIBRATOR, CAMERA, USB, LIGHT SERVICES
# ============================================

# wait
sleep 20

# ============================================
# AML FIX
# ============================================

AML=/data/adb/modules/aml
DIR=$AML$MODSYSTEM/vendor/odm/etc
if [ -d "$DIR" ] && [ ! -f "$AML/disable" ]; then
  chcon -R u:object_r:vendor_configs_file:s0 "$DIR" 2>/dev/null
fi

if [ -f "$MODPATH/copy.sh" ]; then
  AUD=`grep AUD= "$MODPATH/copy.sh" | sed -e 's|AUD=||g' -e 's|"||g'`
  DIR=$AML$MODSYSTEM/vendor
  if [ -d "$AML" ] && [ ! -f "$AML/disable" ] && [ -n "$AUD" ]; then
    FILES=`find "$DIR" -type f -name "$AUD" 2>/dev/null`
    if [ -n "$FILES" ]; then
      if ! grep -q '/odm' "$AML/post-fs-data.sh" 2>/dev/null && [ -d /odm ] && [ "`realpath /odm/etc 2>/dev/null`" = "/odm/etc" ]; then
        for FILE in $FILES; do
          DES=/odm`echo "$FILE" | sed "s|$DIR||g"`
          if [ -f "$DES" ]; then
            umount "$DES" 2>/dev/null
            mount -o bind "$FILE" "$DES" 2>/dev/null
          fi
        done
      fi
      if ! grep -q '/my_product' "$AML/post-fs-data.sh" 2>/dev/null && [ -d /my_product ]; then
        for FILE in $FILES; do
          DES=/my_product`echo "$FILE" | sed "s|$DIR||g"`
          if [ -f "$DES" ]; then
            umount "$DES" 2>/dev/null
            mount -o bind "$FILE" "$DES" 2>/dev/null
          fi
        done
      fi
    fi
  fi
fi

# ============================================
# WAIT FOR BOOT
# ============================================

until [ "`getprop sys.boot_completed`" = "1" ]; do
  sleep 10
done

# ============================================
# DENYLIST MANAGEMENT
# ============================================

if [ -f "$MODPATH/package.txt" ]; then
  PKGS=`cat "$MODPATH/package.txt"`
  for PKG in $PKGS; do
    magisk --denylist rm "$PKG" 2>/dev/null
    magisk --sulist add "$PKG" 2>/dev/null
  done
  if magisk magiskhide sulist 2>/dev/null; then
    for PKG in $PKGS; do
      magisk magiskhide add "$PKG" 2>/dev/null
    done
  else
    for PKG in $PKGS; do
      magisk magiskhide rm "$PKG" 2>/dev/null
    done
  fi
fi

# ============================================
# APP PERMISSIONS
# ============================================

# allow
PKG=com.dolby.daxappui
if appops get "$PKG" > /dev/null 2>&1; then
  if [ "$API" -ge 30 ]; then
    appops set "$PKG" AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore 2>/dev/null
  fi
  if [ "$API" -ge 33 ]; then
    appops set "$PKG" ACCESS_RESTRICTED_SETTINGS allow 2>/dev/null
  fi
fi

# allow
PKG=com.dolby.daxservice
if appops get "$PKG" > /dev/null 2>&1; then
  pm grant --all-permissions "$PKG" 2>/dev/null
  if [ "$API" -ge 30 ]; then
    appops set "$PKG" AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore 2>/dev/null
  fi
  if [ "$API" -ge 33 ]; then
    appops set "$PKG" ACCESS_RESTRICTED_SETTINGS allow 2>/dev/null
  fi
fi

# allow
PKG=com.dolby.atmos
if appops get "$PKG" > /dev/null 2>&1; then
  if [ "$API" -ge 30 ]; then
    appops set "$PKG" AUTO_REVOKE_PERMISSIONS_IF_UNUSED ignore 2>/dev/null
  fi
  if [ "$API" -ge 33 ]; then
    appops set "$PKG" ACCESS_RESTRICTED_SETTINGS allow 2>/dev/null
  fi
fi

# ============================================
# ADDED BACK: restart audioserver once, so the audio_effects
# config patched by .aml.sh (which ran earlier in post-fs-data,
# before audioserver's first read) actually takes effect this
# boot instead of only after a second reboot. audioserver is a
# normal respawn-on-crash init service, restarting it is routine.
# ============================================
if [ ! -f "$MODPATH/.audioserver_kicked" ]; then
  killall audioserver 2>/dev/null
  touch "$MODPATH/.audioserver_kicked" 2>/dev/null
fi

set +x